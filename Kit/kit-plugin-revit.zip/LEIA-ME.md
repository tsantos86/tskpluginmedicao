# Kit plugin .NET (Revit / AutoCAD): licença, Excel e release

Skills e agentes do Claude Code extraídos do TSK TakeOff.

## Instalar

**Num projeto:** extraia este zip na **raiz do projeto**. A pasta `.claude/`
tem de ficar ao lado do `.csproj` ou do `.sln`:

```
MeuPluginRevit/
  .claude/
    agents/
    skills/
  MeuPluginRevit.csproj
```

Pode fazer commit da pasta `.claude/`. Assim quem clonar o repositório recebe o
kit também. Nenhum ficheiro do kit tem chaves ou segredos.

**Em todos os projetos desta máquina:** copie o conteúdo de `.claude/` para
`%USERPROFILE%\.claude\`.

Depois, reinicie o Claude Code, ou abra uma sessão nova, para ele carregar os agentes.

## O que vem

| Nome | Tipo | Para quê |
|---|---|---|
| `orquestrar-plugin` | skill (comando) | encadeia tudo: `/orquestrar-plugin iniciar`, `auditoria` ou `release 1.0.0` |
| `licenciamento-plugin` | skill | trial por e-mail, códigos, postos, offline, Supabase. Traz SQL, C#, painel e teste de segurança em `references/` |
| `excel-plugin-desktop` | skill | exportação ClosedXML e Excel ao vivo por COM, incluindo o threading no Revit |
| `revisor-licenciamento` | agente | audita licença e segurança, só lê e reporta |
| `build-release-plugin` | agente | compila, testa, ofusca, assina, empacota e verifica o pacote |

## Uso típico

```
/orquestrar-plugin iniciar             # num projeto novo: monta licença e Excel
/orquestrar-plugin auditoria           # antes de mostrar a um cliente
/orquestrar-plugin release 1.0.0 --assinar
```

As skills também entram sozinhas quando o assunto aparece na conversa.
Um agente pode ser chamado diretamente: "usa o agente revisor-licenciamento".

## Nunca acontece sem você confirmar

Publicar, instalar nas pastas do Revit/AutoCAD, rodar SQL ou testes contra o
Supabase real, fechar o Revit/AutoCAD.

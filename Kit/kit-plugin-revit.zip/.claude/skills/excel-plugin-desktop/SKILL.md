---
name: excel-plugin-desktop
description: Exportar para Excel e sincronizar ao vivo com uma folha aberta a partir de um plugin .NET (Revit, AutoCAD) ou app desktop — ClosedXML para gerar .xlsx sem Excel, e COM late binding (dynamic, sem PIA) para escrever num Excel aberto, usar o livro-modelo do cliente com as suas fórmulas e macros, e ler de volta o que a pessoa escreveu. Cobre Vista Protegida, avisos modais escondidos, escrita em bloco, cálculo manual, separador de lista regional, HRESULTs típicos e threading no Revit (ExternalEvent, Idling). Usar quando aparecer: Excel ao vivo, exportar Excel, ClosedXML, Excel.Application, COM interop, Value2, FormulaR1C1, Vista Protegida, Zone.Identifier, 0x800A03EC, RPC_E_CALL_REJECTED, folha de medições, mapa de quantidades, livro-modelo.
---

# Excel a partir de um plugin desktop

Destilado do TSK TakeOff (medições em AutoCAD → folha de medição do cliente,
exportação e "Excel ao vivo" em produção). Os números de desempenho foram
medidos lá. `references/ExcelAoVivo.cs` é o esqueleto COM reutilizável,
compilado em net48 (C# 7.3) e net8.0-windows sem avisos.

## Primeiro: qual das duas vias

| | ClosedXML (ficheiro) | COM (Excel aberto) |
|---|---|---|
| Precisa do Excel instalado | não | sim |
| Macros do cliente | perdem-se em `.xlsx` | continuam a correr |
| Fórmulas/formatação do modelo | só se o modelo for `.xlsx` e o abrires | intactas |
| Velocidade | rápida, sem UI | lenta por chamada: tem de ser em bloco |
| Riscos | conflito de versões de DLL no host | caixas modais escondidas, Excel morto, regionais |
| Usar para | "Exportar" (botão, gravar ao lado do projecto) | "Ao vivo", modelo da casa com macros |

O TSK tem as duas: exporta com ClosedXML e sincroniza ao vivo por COM. Se o
cliente não tem modelo próprio com macros, a via ClosedXML chega e dá muito
menos suporte.

## Arquitectura que se paga sozinha

Separar **o que sai** de **como se escreve**:

```
dados do host ──► Construir(...) : List<LinhaFolha>   ◄── lógica pura, sob teste
                         │
          ┌──────────────┼───────────────┐
    ExcelExporter   ExcelAoVivo      (CSV, PDF…)      ◄── só renderizam linhas
    (ClosedXML)       (COM)
```

`LinhaFolha` = tipo (capítulo, artigo, medição, dedução, total), textos e
números já calculados. A construção não conhece o Excel nem o host, por isso
entra no projecto de testes sem Revit/AutoCAD instalado. Foi aí que o TSK
apanhou os erros que saíam num ficheiro com ar de estar certo.

## ClosedXML

- **Versões por alvo.** O TSK usa 0.95.4 no net48 e 0.104.2 no net8. A API
  mudou (a partir da 0.100 `Cell.Value` é um `XLCellValue`): escrever o código
  para o subconjunto comum, ou isolar com `#if`.
- **Nunca atribuir `null` a uma célula.** Em certas versões lança
  `InvalidOperationException` e parte a exportação a meio. Célula vazia =
  não escrever.
- `<CopyLocalLockFileAssemblies>true</CopyLocalLockFileAssemblies>` no csproj:
  o ClosedXML e as dependências (DocumentFormat.OpenXml…) têm de ir para a
  saída, senão o plugin carrega e só rebenta ao exportar.
- **Revit/AutoCAD em net48 partilham um AppDomain entre add-ins.** Se outro
  add-in carregou uma versão diferente do `DocumentFormat.OpenXml` primeiro,
  o teu recebe a dele: `MissingMethodException` só em algumas máquinas. Em
  suporte, perguntar que outros add-ins estão instalados. No .NET 8 confirmar
  como a versão alvo do host isola dependências antes de assumir que já não
  acontece.

## COM ao vivo: o que partiu e porquê

Tudo isto está implementado em `references/ExcelAoVivo.cs`.

**Ligação**
- `Type.GetTypeFromProgID("Excel.Application")` + `Activator.CreateInstance`,
  `dynamic`, sem PIA. `null` = Excel não instalado: dizê-lo e cair na via
  ClosedXML.
- `Workbooks.Count == 0` logo a seguir diz se o processo é nosso. **Nunca
  `Quit()` no Excel do utilizador**; ao desligar, só largar as referências.
- **Ecrã do host "congelado"** = o Excel está a mostrar uma caixa modal atrás
  da janela do host. Desligar `DisplayAlerts`, `AskToUpdateLinks`,
  `AlertBeforeOverwriting`, `FeatureInstall` — **guardando o valor anterior de
  cada um e repondo ao desligar**. No TSK, esquecer a reposição deixava o Excel
  da pessoa sem perguntar "guardar?" o resto do dia.
- `Workbooks.Open(caminho, 0, false)`: o `0` (UpdateLinks) evita a pergunta
  modal "actualizar ligações?".

**Vista Protegida**
- Modelo vindo por e-mail/internet tem o stream `Zone.Identifier`; o Excel
  abre-o em Vista Protegida e o livro fica inacessível (macros incluídas).
  Detectar com `ProtectedViewWindows.Count > 0`, fechar essas janelas e explicar.
- **Trabalhar sempre numa cópia em `%TEMP%`**, copiada **byte a byte com
  FileStream**: `File.Copy` leva o stream alternativo junto, o FileStream não.
  O original do cliente nunca é tocado. Apagar cópias com mais de um dia a
  cada ligação.
- Para desbloquear o próprio modelo: `Unblock-File` no instalador, ou apagar
  o stream `<ficheiro>:Zone.Identifier`. **Cuidado com `File.Replace`**: o
  `ReplaceFile` do Windows preserva os streams nomeados do ficheiro
  substituído, por isso substituir o modelo por uma cópia limpa pode manter a
  marca. O TSK faz assim no `TSKMODELODESBLOQUEAR`; confirmar com
  `Get-Item modelo.xlsx -Stream *` antes de confiar.

**Escrita**
- **Uma chamada COM por bloco, nunca por célula.** Montar um `object[,]`
  (0-based) e atribuir a `Range.Value2` de uma vez.
- **Ler devolve 1-based**, e um intervalo de UMA célula devolve o valor solto,
  não matriz (`LerBloco` normaliza).
- **Congelar durante a escrita**: `ScreenUpdating=false`,
  `Calculation=xlManual`, `EnableEvents=false`, e **repor num `finally`**,
  pela ordem inversa. Sem congelar, o Excel recalcula a folha inteira a cada
  fórmula. Deixá-lo em cálculo manual por um erro é pior que o erro: os totais
  param e ninguém percebe.
- **`Application.Interactive == false`** = a pessoa está a escrever numa
  célula. O Excel recusa quase tudo nesse estado e não devolve o texto a
  meio. Não escrever; pedir Enter e tentar na actualização seguinte.
- **Excel fechado à mão** = referência COM morta; qualquer acesso lança
  (0x80010114 no TSK). Sondar `_app.Version` antes de usar e, se falhar,
  esquecer o estado e deixar voltar a ligar.
- Formatação copiada do modelo: **um `Copy` por tipo de linha, não por
  bloco**. Medido no Excel 2016 com ~360 linhas: 10 081 ms → 643 ms. Colar
  para um destino multi-área baixava a 284 ms mas foi recusado de propósito
  (ver regionais abaixo).
- A altura de linha não vem na colagem de formatos (é da linha, não das
  células): copiar à parte quando importa.

**Regionais: o que depende da máquina do cliente**
- O separador de união de áreas num endereço (`"A1:B2;D1:E2"`) é o **separador
  de lista** do Excel do utilizador (`Application.International(5)`): `;` em
  PT, `,` noutros. Com o errado, 0x800A03EC.
- Endereços têm tecto de 255 caracteres (~20 áreas).
- Fórmulas: escrever com `.Formula` (sintaxe inglesa, vírgulas) ou
  `.FormulaR1C1`; **nunca** `.FormulaLocal`. Números: escrever `double`, nunca
  texto formatado.

**Usar o modelo do cliente em vez de inventar formatação**
- Encontrar o cabeçalho procurando nas primeiras ~40 linhas por palavras
  (ex.: "Item"+"Designação", ou "art"+"descrição"), em qualquer coluna.
- Entre folhas candidatas, **duplicar a mais vazia**, para não arrastar
  medições de outra obra.
- Ler de linhas-exemplo do modelo um molde por tipo de linha (capítulo com
  cor, subtítulo, artigo com `SUM`, medição com dimensões) e aplicá-lo às
  linhas escritas. Muda-se o modelo, muda o aspecto, sem código.
- Ler as fórmulas do modelo em **R1C1** (independentes da linha) e reaplicá-las
  tal e qual.
- **Se o cabeçalho não for reconhecido, não escrever.** Avisar com o que foi
  encontrado em cada folha (ex.: valor de A5 e H5) e continuar numa folha
  simples. Escrever nas colunas erradas de um documento do cliente é pior do
  que não escrever.
- `.xls`/`.xlsm` mantêm macros; exportar para `.xlsx` perde-as. Gravar com a
  extensão do modelo.

**Ler de volta o que a pessoa escreveu**
- Se a pessoa escreve na folha (ex.: códigos de artigo) e isso tem de voltar
  ao modelo do host, recolher **ao desligar e ao fechar o host**, não só na
  escrita seguinte. No TSK, escrever os artigos e fechar sem medir mais perdia
  tudo.
- Guardar o mapa linha → id do elemento no host para saber a quem pertence
  cada texto; nunca confiar na posição depois de a folha ser reescrita.

## Revit: threading

A API do Revit só pode ser chamada no contexto da API (thread principal,
dentro de um comando ou evento). O Excel por COM também quer a thread STA da
UI. Juntas:

1. **Recolher do Revit primeiro, para objectos simples** (POCOs), dentro do
   contexto da API. Fechar a `Transaction` antes de falar com o Excel: uma
   transacção aberta enquanto o Excel mostra uma caixa bloqueia o Revit.
2. **Botão num painel modeless** (dockable pane/janela WPF): não chamar nem o
   Revit nem o Excel no clique. `ExternalEvent.Raise()` e fazer o trabalho no
   `IExternalEventHandler.Execute`.
3. **"Ao vivo"**: `ControlledApplication.DocumentChanged` só **marca como
   sujo** (é chamado muitas vezes e não se pode modificar o documento lá).
   O `UIApplication.Idling` verifica a marca e, com um intervalo mínimo
   (ex.: 500 ms desde a última alteração), recolhe e escreve. Desligar o
   handler de `Idling` quando o ao vivo está desligado: corre sempre que o
   Revit está parado.
4. Nunca abrir `MessageBox` a meio de uma escrita no Excel: log no painel.

## HRESULTs que vais ver

| Código | Significado prático | O que fazer |
|---|---|---|
| `0x800A03EC` | erro genérico do Excel: endereço/fórmula inválida, separador errado, folha protegida | ver o endereço e o separador de lista |
| `0x80010114` | objecto COM já não existe (Excel fechado à mão) — visto no TSK | esquecer o estado, voltar a ligar |
| `0x8001010A` | `RPC_E_SERVERCALL_RETRYLATER`: Excel ocupado (a pessoa num diálogo, a recalcular) | não repetir em ciclo apertado; avisar e tentar na próxima actualização |
| `0x80010001` | `RPC_E_CALL_REJECTED`: idem, recusou a chamada | idem |

Os dois últimos são conhecimento geral de COM, não vistos no TSK: se
aparecerem muito, a solução robusta é um `IMessageFilter` registado na thread.

## Checklist

- [ ] ligar com o Excel fechado, e com o Excel do utilizador já aberto com um livro dele
- [ ] fechar o Excel à mão a meio e voltar a ligar: sem excepção no host
- [ ] escrever com uma célula em edição: não escreve, avisa
- [ ] modelo descarregado da internet: mensagem clara, não ecrã preto
- [ ] depois de desligar, o Excel do utilizador volta a perguntar "guardar?"
- [ ] Windows em PT e em EN (separador de lista `;` vs `,`)
- [ ] 500+ linhas: tempo da primeira escrita e das incrementais
- [ ] sem Excel instalado: exportação ClosedXML continua a funcionar

## Skills irmãs

- `licenciamento-plugin` — exportar nunca deve exigir licença válida.
- `autocad-plugin` — projecto de testes sem o host instalado (serve igual no Revit).

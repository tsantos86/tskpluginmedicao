// =====================================================================
//  Sessão de Excel ao vivo por COM (late binding) — esqueleto reutilizável.
//
//  Destilado do ExcelLiveSync do TSK TakeOff. Tem só a parte que não depende
//  do domínio: ligar, não deixar o Excel do utilizador estragado, congelar
//  durante a escrita, escrever em bloco, detectar edição e morte da ligação.
//
//  Sem referência ao Office (PIA): só precisa de o Excel estar instalado.
//    net48 : <Reference Include="Microsoft.CSharp" />   (para `dynamic`)
//    net8  : nada a acrescentar
//  C# 7.3. Chamar SEMPRE da thread da UI do host (STA). No Revit: dentro de
//  um IExternalCommand ou de um IExternalEventHandler — nunca de uma thread
//  de fundo, nunca com uma Transaction do Revit aberta.
// =====================================================================
using System;
using System.IO;
using System.Runtime.InteropServices;

namespace MeuProduto.Excel
{
    public sealed class ExcelAoVivo
    {
        private const int XlCalculationManual = -4135;
        private const int XlCalculationAutomatic = -4105;

        private dynamic _app;
        private dynamic _wb;
        private bool _instanciaNossa;

        // Definições do Excel que mudamos e TEMOS de devolver. A instância pode
        // ser a do próprio utilizador: deixá-las mudadas era desligar-lhe os
        // avisos de "guardar?" para o resto do dia.
        private object _displayAlertsAntes, _askToUpdateLinksAntes,
                       _alertOverwriteAntes, _featureInstallAntes;

        public dynamic Livro { get { return _wb; } }

        /// <summary>Log para o utilizador (painel do plugin). Nunca MessageBox a meio de uma escrita.</summary>
        public Action<string> Log = delegate { };

        /// <summary>
        /// O Excel ainda está vivo? Não basta o campo não ser nulo: se a pessoa
        /// fechar o Excel à mão, a referência COM fica morta e qualquer acesso
        /// lança (no TSK apareceu 0x80010114). Sonda-se e esquece-se o estado.
        /// </summary>
        public bool Conectado
        {
            get
            {
                if (_app == null) return false;
                try { return _app.Version != null; }
                catch { Esquecer(); return false; }
            }
        }

        /// <summary>
        /// Abre o Excel com uma CÓPIA de trabalho do modelo (o original nunca é
        /// tocado), ou com um livro em branco se <paramref name="modelo"/> for null.
        /// </summary>
        public void Conectar(string modelo, string nomeBase)
        {
            Desconectar();

            var tipo = Type.GetTypeFromProgID("Excel.Application");
            if (tipo == null)
                throw new InvalidOperationException("O Excel não está instalado nesta máquina.");

            try
            {
                _app = Activator.CreateInstance(tipo);
                // Sem livros abertos = processo criado por nós. Com livros, é o
                // Excel do utilizador: nunca lhe fazer Quit.
                try { _instanciaNossa = (int)_app.Workbooks.Count == 0; } catch { _instanciaNossa = false; }
                _app.Visible = true;

                // Caixas modais do Excel ficam ATRÁS da janela do host e o ecrã
                // parece congelado à espera de um clique que ninguém vê.
                try { _displayAlertsAntes = _app.DisplayAlerts; _app.DisplayAlerts = false; } catch { }
                try { _askToUpdateLinksAntes = _app.AskToUpdateLinks; _app.AskToUpdateLinks = false; } catch { }
                try { _alertOverwriteAntes = _app.AlertBeforeOverwriting; _app.AlertBeforeOverwriting = false; } catch { }
                try { _featureInstallAntes = _app.FeatureInstall; _app.FeatureInstall = 0; } catch { }

                if (modelo == null)
                {
                    _wb = _app.Workbooks.Add();
                    return;
                }

                string copia = CopiaDeTrabalho(modelo, nomeBase);
                // Open(Filename, UpdateLinks:=0, ReadOnly:=False): o 0 evita a
                // pergunta "actualizar ligações?", que é modal e bloqueia tudo.
                _wb = _app.Workbooks.Open(copia, 0, false);

                if (VistaProtegida())
                {
                    try { foreach (dynamic pv in _app.ProtectedViewWindows) pv.Close(); } catch { }
                    _wb = null;
                    throw new InvalidOperationException(
                        "O Excel abriu o modelo em Vista Protegida (ficheiro marcado como vindo da " +
                        "internet). Abra-o uma vez no Excel e carregue em \"Activar edição\", " +
                        "ou desbloqueie-o nas Propriedades do ficheiro.");
                }
            }
            catch
            {
                if (_instanciaNossa) try { _app.Quit(); } catch { }
                ReporDefinicoes();
                Esquecer();       // nunca deixar meio-ligado
                throw;
            }
        }

        /// <summary>Larga o Excel sem o fechar. Devolve as definições que mudámos.</summary>
        public void Desconectar()
        {
            ReporDefinicoes();
            Libertar(_wb);
            Libertar(_app);
            Esquecer();
        }

        /// <summary>
        /// A pessoa está a escrever numa célula. Nesse estado o Excel recusa quase
        /// tudo (e não devolve o texto a meio). Não escrever; avisar e esperar.
        /// </summary>
        public bool EmEdicao()
        {
            try { return !(bool)_app.Interactive; }
            catch { return true; }   // na dúvida, não mexer
        }

        /// <summary>
        /// Corre <paramref name="escrita"/> com o Excel congelado e repõe tudo no
        /// fim, mesmo que rebente. Sem congelar, o Excel redesenha e RECALCULA a
        /// folha inteira a cada fórmula — com centenas de linhas é aí que vai o
        /// tempo, não na escrita. Devolve false se não escreveu.
        /// </summary>
        public bool Escrever(Action<dynamic> escrita)
        {
            if (!Conectado) return false;
            if (EmEdicao())
            {
                Log("Excel em edição: termine a célula (Enter) e volte a actualizar.");
                return false;
            }

            object calcAntes = null;
            try
            {
                _app.ScreenUpdating = false;
                try { calcAntes = _app.Calculation; _app.Calculation = XlCalculationManual; } catch { }
                try { _app.EnableEvents = false; } catch { }

                escrita(_wb);
                return true;
            }
            catch (COMException ex)
            {
                // Antes morria em silêncio: o Excel deixava de actualizar e
                // ninguém sabia porquê. Dizer o HRESULT, largar, e deixar voltar a ligar.
                Log("Excel ao vivo parou [COM 0x" + ex.ErrorCode.ToString("X8") + "]: " + ex.Message);
                ReporDefinicoes();
                Esquecer();
                return false;
            }
            catch (Exception ex)
            {
                Log("Excel ao vivo parou [" + ex.GetType().Name + "]: " + ex.Message);
                ReporDefinicoes();
                Esquecer();
                return false;
            }
            finally
            {
                // Pela ordem inversa e SEMPRE. Deixar o Excel em cálculo manual é
                // pior do que o erro: os totais param e ninguém percebe porquê.
                try { if (_app != null) _app.EnableEvents = true; } catch { }
                try { if (_app != null) _app.Calculation = calcAntes ?? (object)XlCalculationAutomatic; } catch { }
                try { if (_app != null) _app.ScreenUpdating = true; } catch { }
            }
        }

        // ==================================================================
        // Leitura e escrita em bloco — uma chamada COM por bloco, não por célula
        // ==================================================================

        /// <summary>
        /// Escreve uma matriz de uma vez. <paramref name="dados"/> é 0-based
        /// [linhas, colunas]; o Excel aceita-a tal e qual. Uma chamada COM por
        /// célula custa ~1 ms cada — 5000 células são 5 s de ecrã parado.
        /// </summary>
        public static void EscreverBloco(dynamic folha, int linha1, int coluna1, object[,] dados)
        {
            int n = dados.GetLength(0), m = dados.GetLength(1);
            if (n == 0 || m == 0) return;
            dynamic destino = folha.Range[folha.Cells[linha1, coluna1],
                                          folha.Cells[linha1 + n - 1, coluna1 + m - 1]];
            destino.Value2 = dados;
        }

        /// <summary>
        /// Lê uma coluna de uma vez. ATENÇÃO: o que o Excel devolve é 1-based
        /// ([1..n, 1..1]), e se o intervalo tiver UMA célula devolve o valor
        /// solto, não uma matriz. Esta função normaliza os dois casos.
        /// </summary>
        public static object[,] LerBloco(dynamic folha, int linha1, int coluna1, int linha2, int coluna2)
        {
            object v = folha.Range[folha.Cells[linha1, coluna1], folha.Cells[linha2, coluna2]].Value2;
            var matriz = v as object[,];
            if (matriz != null) return matriz;
            var unica = (object[,])Array.CreateInstance(typeof(object), new[] { 1, 1 }, new[] { 1, 1 });
            unica[1, 1] = v;
            return unica;
        }

        /// <summary>
        /// Texto de uma célula. Em células unidas o Value2 vem nulo fora da
        /// primeira: cai para o texto mostrado.
        /// </summary>
        public static string Texto(dynamic folha, int linha, int coluna)
        {
            try
            {
                object v = folha.Cells[linha, coluna].Value2;
                if (v != null) return Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture);
                return (string)folha.Cells[linha, coluna].Text ?? "";
            }
            catch { return ""; }
        }

        // ==================================================================
        // Ficheiros
        // ==================================================================

        /// <summary>
        /// Copia o modelo para %TEMP%\Produto com data no nome. Cópia BYTE A BYTE
        /// de propósito: File.Copy leva o stream Zone.Identifier ("veio da
        /// internet") e o Excel abre a cópia em Vista Protegida — inacessível
        /// ao plugin e com as macros bloqueadas. Um FileStream não copia streams
        /// alternativos.
        /// </summary>
        public static string CopiaDeTrabalho(string modelo, string nomeBase)
        {
            string pasta = Path.Combine(Path.GetTempPath(), "MeuProduto");
            Directory.CreateDirectory(pasta);
            LimparCopiasAntigas(pasta);

            if (string.IsNullOrWhiteSpace(nomeBase)) nomeBase = "folha";
            foreach (char c in Path.GetInvalidFileNameChars()) nomeBase = nomeBase.Replace(c, '_');

            string destino = Path.Combine(pasta, nomeBase + "_" +
                DateTime.Now.ToString("yyyyMMdd_HHmmss") + Path.GetExtension(modelo));
            using (var e = new FileStream(modelo, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var s = new FileStream(destino, FileMode.Create, FileAccess.Write, FileShare.None))
                e.CopyTo(s);
            try { File.SetAttributes(destino, FileAttributes.Normal); } catch { }
            return destino;
        }

        /// <summary>Cada ligação cria uma cópia; sem isto acumulam-se para sempre.</summary>
        private static void LimparCopiasAntigas(string pasta)
        {
            try
            {
                DateTime limite = DateTime.Now.AddDays(-1);
                foreach (string f in Directory.GetFiles(pasta))
                    try { if (File.GetLastWriteTime(f) < limite) File.Delete(f); } catch { }  // em uso: fica para a próxima
            }
            catch { }
        }

        // ==================================================================
        private bool VistaProtegida()
        {
            try { return (int)_app.ProtectedViewWindows.Count > 0; }
            catch { return false; }
        }

        private void ReporDefinicoes()
        {
            try
            {
                if (_app != null)
                {
                    if (_displayAlertsAntes != null) _app.DisplayAlerts = _displayAlertsAntes;
                    if (_askToUpdateLinksAntes != null) _app.AskToUpdateLinks = _askToUpdateLinksAntes;
                    if (_alertOverwriteAntes != null) _app.AlertBeforeOverwriting = _alertOverwriteAntes;
                    if (_featureInstallAntes != null) _app.FeatureInstall = _featureInstallAntes;
                }
            }
            catch { }
            _displayAlertsAntes = _askToUpdateLinksAntes = _alertOverwriteAntes = _featureInstallAntes = null;
        }

        private void Esquecer()
        {
            _wb = null; _app = null; _instanciaNossa = false;
            _displayAlertsAntes = _askToUpdateLinksAntes = _alertOverwriteAntes = _featureInstallAntes = null;
        }

        private static void Libertar(object o)
        {
            try { if (o != null && Marshal.IsComObject(o)) Marshal.ReleaseComObject(o); } catch { }
        }
    }
}

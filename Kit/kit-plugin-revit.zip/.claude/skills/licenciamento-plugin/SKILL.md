---
name: licenciamento-plugin
description: Licenciar um plugin ou app desktop .NET (Revit, AutoCAD, WinForms/WPF) com avaliação gratuita por e-mail, códigos de activação, limite de postos, tolerância offline e painel de administração, sobre Supabase (RLS, RPC security definer, chave anon pública). Inclui esquema SQL consolidado, classe C# net48/net8 pronta, teste de fuga com a chave anon e painel HTML. Usar quando aparecer: licença, licenciamento, trial, avaliação gratuita, código de activação, activar posto, max_dispositivos, DPAPI, ProtectedData, pedir_trial, activar_licenca, service_role, chave anon, "liberar mais dias", estender trial, revogar licença, ofuscação da verificação de licença.
---

# Licenciamento de plugin desktop

Destilado do TSK TakeOff (plugin AutoCAD em produção com clientes). Serve
igual para Revit ou qualquer app .NET no Windows: o host só entra em três
pontos (onde se chama, que janela é dona do diálogo, que versão se reporta).

Tudo o que está em `references/` foi compilado ou corrido:

| Ficheiro | O que é |
|---|---|
| `references/schema.sql` | Esquema completo, já com as 3 correcções de segurança que o TSK precisou em produção. Corre de uma vez; termina com uma verificação. |
| `references/Licenca.cs` | Classe cliente, C# 7.3, compila em net48 e net8.0-windows sem avisos. Independente do host. |
| `references/testar_anon.ps1` | Ataca o projecto com a chave pública e confirma que só o necessário está aberto. |
| `references/painel-admin.html` | Painel local (emitir, renovar, revogar, estender trial, ver postos). Com escape de HTML — o original não tinha. |

## Arquitectura

```
Plugin (chave publishable, pública por construção)
   │  POST /rest/v1/rpc/activar_licenca | verificar_licenca | pedir_trial
   ▼
Supabase ── tabelas com RLS a negar tudo
         ── 3 funções SECURITY DEFINER para o anon (respondem sim/não)
         ── funções de admin + vistas security_invoker só para service_role
   ▲
Painel HTML local (service_role, colada a cada abertura, nunca guardada)
```

## Regras que não se quebram

1. **Nunca atrasar o arranque do host.** A revalidação corre numa thread em
   segundo plano, uma vez por dia, sem diálogos e sem tocar na API do host.
2. **Sem internet, vale a validade local.** Quem está em obra continua a
   trabalhar até ao fim da janela (`dias` da licença, 30 por omissão).
3. **Expirada, bloqueia criar; nunca bloqueia ver nem exportar.** Reter
   trabalho já feito é a forma mais rápida de perder um cliente.
4. **O trial nunca se renova em silêncio.** É uma janela única emitida pelo
   servidor. Só uma licença paga faz verificação online quando expira.
5. **A chave que vai com o plugin é pública.** Toda a segurança está no
   servidor. Se a chave do cliente abrir alguma coisa além das 3 RPC, é fuga.
6. **Licenciamento desktop é um dissuasor, não uma fortaleza.** A DLL .NET
   decompila-se. Ofuscar sobe o custo; não vale investir muito além disso.

## Identidade do posto

Um GUID gerado na primeira utilização, guardado em
`%APPDATA%\<Produto>\instalacao.dat` cifrado com DPAPI (`CurrentUser`).

- **Não usar `Environment.MachineName`.** O utilizador muda-o quando quer. No
  TSK, renomear o Windows dava uma avaliação nova.
- **Usar o mesmo GUID para o trial e para as activações pagas.** O TSK ficou
  com `PC\UTILIZADOR` nas pagas por compatibilidade. Num projecto novo, não.
- DPAPI `CurrentUser` significa: copiar a pasta para outro PC ou outra conta
  Windows não leva nada. Consequência: a mesma pessoa em duas contas Windows
  ocupa dois postos. Aceitável, e o painel liberta lugares.
- O trial fica preso **à instalação OU ao e-mail**: qualquer um dos dois já
  usado devolve o trial existente. Apagar o `.dat` gera outro GUID, mas o
  e-mail trava. Trocar de e-mail no mesmo PC não passa, porque o GUID trava.

## Estado local

`licenca.dat` (DPAPI) com código, cliente, e-mail, `expira_em`,
`verificado_em` e motivo. Três protecções que custaram bugs a descobrir:

- **Cópia `.bak` antes de cada escrita**, e leitura do `.bak` se o principal
  estiver corrompido, reparando o principal a seguir. Sem a reparação, o
  `Guardar` seguinte copiava o ficheiro estragado por cima do backup bom.
- **Relógio para trás.** Se `UtcNow + 6h < verificado_em`, alguém atrasou o
  relógio: a validade local deixa de valer até haver verificação online. Sem
  isto, mudar a data do Windows esticava qualquer licença, até uma revogada.
- **Recusa do servidor**: numa licença paga corta já (`ExpiraEm = MinValue`);
  num trial mantém a data original, para a UI dizer quando acabou.

## Servidor: as três armadilhas do Supabase

As três aconteceram em produção no TSK. O `schema.sql` já as fecha, mas
quem mexer no esquema tem de as conhecer:

1. **`revoke ... from public` não tira nada ao `anon`.** Projectos com os
   privilégios por omissão antigos dão ao `anon` uma concessão própria em cada
   objecto novo. O TSK ficou com `emitir_licenca` executável pela chave da DLL.
   Revogar sempre `from anon, authenticated, public` e fechar os
   `alter default privileges` **antes** de criar objectos.
2. **Vistas ignoram a RLS.** Correm com as permissões do dono. A `vw_licencas`
   do TSK mostrava os códigos de todos os clientes à chave anon. Criar sempre
   `with (security_invoker = true)` e dar SELECT nas tabelas ao `service_role`.
3. **Revogar de PUBLIC também tira ao `service_role`.** Uma função nova nasce
   com EXECUTE para PUBLIC, e é daí que o service_role a herda. Depois do
   revoke, o painel deixou de emitir. Conceder sempre explicitamente.

Outras regras de servidor:
- Todas as funções `security definer` levam `set search_path = public`.
- Comparar códigos sempre por `normalizar_codigo()`: o cliente cola
  `abc 1a2b-3c4d`. No TSK o revogar exigia o código exacto e respondia "não
  encontrado" a um pedido de revogação urgente.
- `activar_licenca` faz `select ... for update` na licença para dois postos
  simultâneos não passarem ambos o limite.
- `pedir_trial` usa `pg_advisory_xact_lock` por e-mail pela mesma razão.
- `gerar_codigo()` usa `gen_random_uuid()` (48 bits fortes). Não usar
  `md5(random())` (não é criptográfico), nem `gen_random_bytes` com
  `search_path = public` (o pgcrypto do Supabase vive em `extensions`).
- Revogar **não é imediato**: o posto só perde acesso na revalidação seguinte
  (arranque com rede, ou no máximo `dias` dias). Dizê-lo ao cliente assim.

Depois de qualquer alteração ao esquema: correr a consulta de verificação no
fim do `schema.sql` **e** o `testar_anon.ps1`. A primeira vê privilégios; o
segundo vê o que um atacante vê de facto, incluindo o caso em que o privilégio
existe mas a RLS devolve `[]` (conta como falha: o privilégio não devia estar lá).

## Painel de administração

- Um ficheiro HTML local que pede a `service_role` a cada abertura e **nunca a
  guarda**. Nunca vai no instalador. Se a chave sair do computador de quem
  vende, rodar em Project Settings → API Keys.
- **Escapar tudo o que vem da base.** `instalacao`, `utilizador` e versões são
  escritos pelo plugin, ou seja, por qualquer pessoa com a DLL, e o painel tem
  a service_role em memória. O painel do TSK metia esses campos em `innerHTML`
  sem escape: bastava um nome de utilizador com `<img onerror>`.
- O plugin recusa arrancar a licença se o `supabase.json` trouxer
  `sb_secret_…` ou uma JWT com `"role":"service_role"` (já em `Licenca.cs`).

## Operações do dia-a-dia

No painel, ou no SQL Editor:

```sql
-- "Preciso de mais 15 dias" (trial). Depois o cliente abre o diálogo de
-- licença e pede a avaliação de novo com o MESMO e-mail.
select public.estender_trial('pessoa@cliente.pt', 15);

-- Licença anual para 3 postos
select public.emitir_licenca('Construtora X', 'geral@x.pt', 30, 3,
                             (current_date + interval '1 year')::date, 'fatura 2026/114');

-- Cliente mudou de PC: libertar o lugar antigo
select public.libertar_posto('ABC-1A2B-3C4D-5E6F', '<GUID da instalação antiga>');

-- Renovar / cortar
select public.renovar_licenca('ABC-1A2B-3C4D-5E6F', '2027-12-31');
select public.revogar_licenca('ABC-1A2B-3C4D-5E6F');
```

Se o cliente vai continuar a usar, emitir uma licença curta (`dias = 15`)
converte e mede melhor do que esticar o trial.

## Integração no Revit

```csharp
public class App : IExternalApplication
{
    public Result OnStartup(UIControlledApplication app)
    {
        // Tudo o que vem da API lê-se AQUI, na thread do Revit — a thread de
        // rede não pode tocar na API.
        IntPtr dono = app.MainWindowHandle;
        Licenca.Configurar(new LicencaConfig
        {
            Produto = "MeuPlugin",
            EmailContacto = "vendas@exemplo.pt",
            VersaoHost = "Revit " + app.ControlledApplication.VersionNumber,
            Log = msg => Debug.WriteLine(msg),          // ou o painel do plugin
            MostrarDialogo = () =>
            {
                using (var dlg = new LicencaDialog())    // WinForms: e-mail + código
                    dlg.ShowDialog(new JanelaNativa(dono));
            }
        });
        Licenca.VerificarNoArranque();                   // thread própria, silenciosa
        return Result.Succeeded;
    }
    public Result OnShutdown(UIControlledApplication app) { return Result.Succeeded; }
}

sealed class JanelaNativa : System.Windows.Forms.IWin32Window
{
    public JanelaNativa(IntPtr h) { Handle = h; }
    public IntPtr Handle { get; private set; }
}

[Transaction(TransactionMode.Manual)]
public class CmdMedir : IExternalCommand
{
    public Result Execute(ExternalCommandData data, ref string message, ElementSet elements)
    {
        if (!Licenca.PodeUsar()) return Result.Cancelled;   // só comandos que CRIAM trabalho
        // ...
        return Result.Succeeded;
    }
}
```

- `PodeUsar()` pode abrir o diálogo: chamar só na thread do Revit (dentro de
  `Execute` ou de um `IExternalEventHandler`), nunca de uma thread de fundo.
- O diálogo chama `Licenca.PedirTrial(email)` / `Licenca.Activar(codigo)`, que
  são síncronos: desactivar os botões e mostrar "A contactar o servidor…"
  antes da chamada, senão o clique parece ignorado.
- Comandos de consulta e exportação **não** chamam `PodeUsar()`.
- `supabase.json` vai ao lado da DLL (junto do `.addin`) ou em
  `%APPDATA%\<Produto>\`. Formato: `{"url":"https://x.supabase.co","chave":"sb_publishable_…"}`.
- Revit 2021–2024 carrega net48 e 2025+ carrega net8: o `Licenca.cs` compila nos
  dois; no net8 falta só o pacote `System.Security.Cryptography.ProtectedData`.

## Ofuscação

Se ofuscar, a regra de exclusão tem de cobrir tudo o que o host encontra
**por nome**: no Revit, as classes indicadas em `FullClassName` no `.addin`
(`IExternalApplication`, `IExternalCommand`) e as classes de UI com XAML. A
classe de licença é onde a ofuscação compensa (`anti tamper`). Anti-debug e
anti-dump ficam desligados: dão falsos positivos no Defender, e isso custa
mais vendas do que a pirataria que evitam. Ordem: compilar → ofuscar →
assinar (assinar antes invalida a assinatura).

## Telemetria (opcional, mas usa a mesma identidade)

Uma linha por arranque, **só depois de a pessoa aceitar**, com o GUID da
instalação, as versões, o SO e a cultura. Nunca utilizador, máquina ou domínio.
A escolha fica num ficheiro à parte do `supabase.json`, para uma reinstalação
não religar o envio a quem disse que não. Ao recusar, apagar a fila pendente.
**Ler a configuração do mesmo `ConfigSupabase` da licença.** No TSK a
telemetria lia `telemetria.json` enquanto a documentação e o instalador
distribuíam `supabase.json`, e deixou de enviar sem erro nenhum.

## Checklist antes de vender

- [ ] `schema.sql` corrido; a verificação final diz tudo "passa"
- [ ] `testar_anon.ps1` com o `supabase.json` **que vai no instalador**: 0 falhas
- [ ] o `supabase.json` distribuído tem a chave publishable, nunca a secret
- [ ] o painel não está no instalador
- [ ] comandos de ver/exportar funcionam com a licença expirada
- [ ] com o PC offline, uma licença válida continua a funcionar
- [ ] atrasar o relógio do Windows um dia não estica a licença
- [ ] a ofuscação (se houver) não partiu o carregamento: abrir o host e correr
      um comando de cada classe excluída

## Skills irmãs

- `excel-plugin-desktop` — exportar e sincronizar ao vivo com o Excel a
  partir de um plugin (ClosedXML e COM).
- `autocad-plugin` — estrutura, dual-target e distribuição de um plugin AutoCAD.

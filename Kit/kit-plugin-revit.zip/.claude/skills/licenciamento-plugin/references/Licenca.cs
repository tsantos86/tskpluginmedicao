// =====================================================================
//  Licenciamento por código + avaliação gratuita, contra o Supabase.
//
//  Template independente do host (Revit, AutoCAD, app WinForms/WPF).
//  Escrito em C# 7.3 DE PROPÓSITO: compila em net48 (Revit/AutoCAD até 2024)
//  e em net8.0-windows (2025+) sem #if, a não ser o aviso do WebRequest.
//
//  Referências necessárias:
//    net48 : <Reference Include="System.Security" />            (DPAPI)
//    net8  : <PackageReference Include="System.Security.Cryptography.ProtectedData" Version="8.0.0" />
//
//  Princípios que não se quebram:
//   - nunca bloqueia nem atrasa o arranque do host (verifica em thread própria);
//   - sem internet, vale a validade guardada localmente;
//   - expirada, bloqueia CRIAR trabalho novo, nunca ver nem exportar o já feito;
//   - o estado local é cifrado com DPAPI (preso ao utilizador Windows), por
//     isso copiar a pasta para outro PC não leva a licença.
// =====================================================================
using System;
using System.Globalization;
using System.IO;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

#if NET5_0_OR_GREATER
#pragma warning disable SYSLIB0014 // WebRequest: obsoleto mas funciona; mantém uma só implementação para net48 e net8
#endif

namespace MeuProduto.Licenciamento
{
    /// <summary>O que muda de produto para produto. Preencher uma vez no arranque.</summary>
    public sealed class LicencaConfig
    {
        /// <summary>Nome da pasta em %APPDATA% e prefixo das mensagens.</summary>
        public string Produto = "MeuProduto";
        public string EmailContacto = "suporte@exemplo.com";
        public int DiasTrial = 15;
        public int DiasToleranciaOffline = 30;

        /// <summary>Ex.: "Revit 2025". Lido NO ARRANQUE, na thread do host — nunca numa thread de rede.</summary>
        public string VersaoHost = "?";

        /// <summary>Escreve uma linha para o utilizador (painel, linha de comando, log).</summary>
        public Action<string> Log = delegate { };

        /// <summary>
        /// Mostra o diálogo de licença (e-mail para trial + campo de código) de
        /// forma MODAL e na thread da UI do host. No Revit: dentro de um
        /// IExternalCommand, com a janela do Revit como dono.
        /// </summary>
        public Action MostrarDialogo = delegate { };
    }

    public static class Licenca
    {
        private const string RpcActivar = "activar_licenca";
        private const string RpcVerificar = "verificar_licenca";
        private const string RpcTrial = "pedir_trial";
        private const string CodigoTrial = "TRIAL";

        /// <summary>
        /// Margem antes de se considerar que o relógio recuou. Há razões
        /// inocentes para o relógio andar umas horas para trás: NTP,
        /// hibernação, fuso mal configurado.
        /// </summary>
        private static readonly TimeSpan FolgaDoRelogio = TimeSpan.FromHours(6);

        private static LicencaConfig _cfg = new LicencaConfig();
        private static Estado _estado;
        private static string _idInstalacao;
        private static bool _verificado;
        private static readonly object _lock = new object();

        public static void Configurar(LicencaConfig cfg)
        {
            if (cfg == null) throw new ArgumentNullException("cfg");
            _cfg = cfg;
        }

        private class Estado
        {
            public string Codigo = "";
            public string Cliente = "";
            public string Email = "";
            public string Motivo = "";
            public DateTime ExpiraEm = DateTime.MinValue;          // UTC
            public DateTime UltimaVerificacao = DateTime.MinValue; // UTC
        }

        private static string Pasta
        {
            get
            {
                return Path.Combine(Environment.GetFolderPath(
                    Environment.SpecialFolder.ApplicationData), _cfg.Produto);
            }
        }
        private static string Ficheiro { get { return Path.Combine(Pasta, "licenca.dat"); } }
        private static string FicheiroInstalacao { get { return Path.Combine(Pasta, "instalacao.dat"); } }

        // ==================================================================
        // Identidade
        // ==================================================================

        /// <summary>
        /// GUID gerado na primeira utilização e guardado cifrado. É A identidade
        /// do posto, para o trial E para as activações pagas.
        ///
        /// Não usar Environment.MachineName: o utilizador muda-o quando quer, e
        /// no TSK renomear o Windows dava uma avaliação nova. O TSK ficou com
        /// MachineName\UserName nas activações pagas só por compatibilidade —
        /// num projecto novo não há razão para repetir.
        /// </summary>
        public static string IdentificadorInstalacao
        {
            get
            {
                lock (_lock)
                {
                    if (!string.IsNullOrEmpty(_idInstalacao)) return _idInstalacao;
                    try
                    {
                        if (File.Exists(FicheiroInstalacao))
                        {
                            string lido = Encoding.UTF8.GetString(ProtectedData.Unprotect(
                                File.ReadAllBytes(FicheiroInstalacao), null,
                                DataProtectionScope.CurrentUser)).Trim();
                            Guid g;
                            if (Guid.TryParseExact(lido, "N", out g))
                                return _idInstalacao = lido.ToUpperInvariant();
                        }
                    }
                    catch { }

                    _idInstalacao = Guid.NewGuid().ToString("N").ToUpperInvariant();
                    try
                    {
                        Directory.CreateDirectory(Pasta);
                        File.WriteAllBytes(FicheiroInstalacao, ProtectedData.Protect(
                            Encoding.UTF8.GetBytes(_idInstalacao), null,
                            DataProtectionScope.CurrentUser));
                    }
                    catch { }
                    return _idInstalacao;
                }
            }
        }

        // ==================================================================
        // Estado público
        // ==================================================================

        public static bool Valida
        {
            get
            {
                var e = Carregar();
                if (e == null || string.IsNullOrEmpty(e.Codigo)) return false;
                if (RelogioAndouParaTras(e)) return false;
                return e.ExpiraEm > DateTime.UtcNow;
            }
        }

        public static bool EmAvaliacao
        {
            get
            {
                var e = Carregar();
                return e != null && e.Codigo == CodigoTrial && e.ExpiraEm > DateTime.UtcNow;
            }
        }

        public static int DiasRestantes
        {
            get
            {
                var e = Carregar();
                if (e == null || e.ExpiraEm <= DateTime.UtcNow) return 0;
                return (int)Math.Ceiling((e.ExpiraEm - DateTime.UtcNow).TotalDays);
            }
        }

        public static string Email { get { var e = Carregar(); return e == null ? "" : e.Email; } }

        public static string Resumo()
        {
            var e = Carregar();
            if (e == null || string.IsNullOrEmpty(e.Codigo))
                return "sem licença";
            string ate = e.ExpiraEm.ToLocalTime().ToString("dd/MM/yyyy");
            if (e.ExpiraEm <= DateTime.UtcNow)
                return "licença expirada em " + ate +
                       (string.IsNullOrEmpty(e.Motivo) ? "" : " (" + e.Motivo + ")") +
                       ". Contacte " + _cfg.EmailContacto + ".";
            if (e.Codigo == CodigoTrial)
                return "avaliação gratuita · " + DiasRestantes + " dia(s) restantes (até " + ate + ")";
            return (string.IsNullOrEmpty(e.Cliente) ? "" : e.Cliente + " · ") +
                   DiasRestantes + " dia(s) restantes (até " + ate + ")";
        }

        /// <summary>
        /// O tempo não anda para trás. Se o relógio está antes do instante em
        /// que falámos com o servidor, alguém lhe mexeu — e a validade local
        /// deixa de valer até uma verificação online repor a verdade. Sem isto,
        /// atrasar a data do Windows esticava a licença para sempre, sem rede.
        /// </summary>
        private static bool RelogioAndouParaTras(Estado e)
        {
            if (e.UltimaVerificacao == DateTime.MinValue) return false;
            return DateTime.UtcNow + FolgaDoRelogio < e.UltimaVerificacao;
        }

        // ==================================================================
        // Porta de entrada
        // ==================================================================

        /// <summary>
        /// Chamar no início de cada comando que CRIA trabalho. Ver, consultar e
        /// exportar nunca passam por aqui — ninguém fica com trabalho retido.
        /// Tem de correr na thread da UI do host (pode abrir o diálogo).
        /// </summary>
        public static bool PodeUsar()
        {
            if (Valida) return true;

            var e = Carregar();
            if (e == null || string.IsNullOrEmpty(e.Codigo))
            {
                _cfg.Log("Este posto ainda não está licenciado. Indique o e-mail para " +
                         "iniciar a avaliação de " + _cfg.DiasTrial + " dias.");
                return PedirAoUtilizador();
            }

            _cfg.Log("Licença expirada" + (string.IsNullOrEmpty(e.Motivo) ? "" : " — " + e.Motivo) +
                     ". O trabalho existente continua visível e exportável.");

            // O trial é uma janela única emitida pelo servidor: nunca se renova
            // em silêncio. Uma licença paga pode ter sido renovada no painel,
            // por isso pergunta-se — com timeout curto e aviso antes, porque
            // isto é síncrono e quem clicou não pode ficar 12 s congelado.
            if (e.Codigo != CodigoTrial)
            {
                _cfg.Log("A verificar a licença junto do servidor…");
                if (VerificarOnline(e.Codigo, 4000)) return true;
            }
            return PedirAoUtilizador();
        }

        private static bool PedirAoUtilizador()
        {
            try { _cfg.MostrarDialogo(); } catch { }
            return Valida;
        }

        /// <summary>
        /// Revalidação silenciosa. Chamar uma vez no arranque do host. Corre em
        /// thread própria, não abre diálogos e não toca na API do host.
        /// </summary>
        public static void VerificarNoArranque()
        {
            if (_verificado) return;
            _verificado = true;
            try
            {
                new Thread(() =>
                {
                    try
                    {
                        var e = Carregar();
                        if (e == null || string.IsNullOrEmpty(e.Codigo)) return;  // instalação nova: o 1.º comando trata
                        if (e.Codigo == CodigoTrial) return;                        // trial: ou está no prazo, ou acabou
                        if ((DateTime.UtcNow - e.UltimaVerificacao).TotalHours < 24 &&
                            e.ExpiraEm > DateTime.UtcNow && !RelogioAndouParaTras(e))
                            return;                                                 // uma vez por dia chega
                        VerificarOnline(e.Codigo, 12000);
                    }
                    catch { }
                }) { IsBackground = true }.Start();
            }
            catch { }
        }

        // ==================================================================
        // Pedidos ao servidor (devolvem mensagem de erro, ou null se correu bem)
        // ==================================================================

        public static string PedirTrial(string email)
        {
            email = (email ?? "").Trim();
            if (!Regex.IsMatch(email, @"^[^\s@]+@[^\s@]+\.[^\s@]+$"))
                return "Indique um e-mail válido para iniciar a avaliação.";

            string url, chave;
            if (!ConfigSupabase.Ler(_cfg.Produto, out url, out chave))
                return "Falta a configuração do servidor (supabase.json).";

            string corpo = "{" +
                Campo("p_instalacao", IdentificadorInstalacao) + "," +
                Campo("p_email", email) + "," +
                Campo("p_utilizador", Environment.UserName) + "," +
                Campo("p_versao_host", _cfg.VersaoHost) + "," +
                Campo("p_versao_plugin", VersaoPlugin()) + "}";

            string resposta;
            try { resposta = Post(url, chave, RpcTrial, corpo, 12000); }
            catch (WebException) { return "Não foi possível contactar o servidor."; }
            catch (Exception ex) { return "Erro ao pedir a avaliação: " + ex.Message; }
            return AplicarResposta(CodigoTrial, resposta, email);
        }

        public static string Activar(string codigo)
        {
            codigo = Normalizar(codigo);
            if (codigo.Length < 6) return "O código parece incompleto.";

            string url, chave;
            if (!ConfigSupabase.Ler(_cfg.Produto, out url, out chave))
                return "Falta a configuração do servidor (supabase.json).";

            string corpo = "{" +
                Campo("p_codigo", codigo) + "," +
                Campo("p_instalacao", IdentificadorInstalacao) + "," +
                Campo("p_utilizador", Environment.UserName) + "," +
                Campo("p_versao_host", _cfg.VersaoHost) + "," +
                Campo("p_versao_plugin", VersaoPlugin()) + "}";

            string resposta;
            try { resposta = Post(url, chave, RpcActivar, corpo, 12000); }
            catch (WebException) { return "Não foi possível contactar o servidor. Verifique a internet."; }
            catch (Exception ex) { return "Erro ao activar: " + ex.Message; }
            return AplicarResposta(codigo, resposta, null);
        }

        private static bool VerificarOnline(string codigo, int timeoutMs)
        {
            string url, chave;
            if (!ConfigSupabase.Ler(_cfg.Produto, out url, out chave)) return Valida;
            try
            {
                string corpo = "{" + Campo("p_codigo", codigo) + "," +
                                     Campo("p_instalacao", IdentificadorInstalacao) + "}";
                return AplicarResposta(codigo, Post(url, chave, RpcVerificar, corpo, timeoutMs), null) == null;
            }
            catch
            {
                return Valida;   // offline: vale o que está guardado
            }
        }

        private static string AplicarResposta(string codigo, string json, string email)
        {
            if (string.IsNullOrWhiteSpace(json)) return "Resposta vazia do servidor.";

            bool ok = Regex.IsMatch(json, "\"ok\"\\s*:\\s*true");
            string motivo = Extrair(json, "motivo");

            if (!ok)
            {
                var e = Carregar() ?? new Estado();
                e.Motivo = motivo ?? "Licença recusada.";
                // Trial recusado: mantém a data original, para a UI mostrar
                // quando acabou. Paga recusada/revogada: corta já.
                if (e.Codigo != CodigoTrial) e.ExpiraEm = DateTime.MinValue;
                Guardar(e);
                return e.Motivo;
            }

            DateTime expira = Data(Extrair(json, "expira_em"));
            if (expira == DateTime.MinValue)
                expira = DateTime.UtcNow.AddDays(_cfg.DiasToleranciaOffline);

            var anterior = Carregar();
            Guardar(new Estado
            {
                Codigo = codigo,
                Cliente = Extrair(json, "cliente") ?? "",
                Email = email ?? (anterior == null ? "" : anterior.Email),
                ExpiraEm = expira,
                UltimaVerificacao = DateTime.UtcNow,
                Motivo = ""
            });
            return null;
        }

        private static string Post(string url, string chave, string funcao, string corpo, int timeoutMs)
        {
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
            var req = (HttpWebRequest)WebRequest.Create(url.TrimEnd('/') + "/rest/v1/rpc/" + funcao);
            req.Method = "POST";
            req.ContentType = "application/json";
            req.Headers.Add("apikey", chave);
            // Com as chaves novas (sb_publishable_…) o Authorization não é
            // obrigatório, mas com a anon JWT antiga é. Mandar os dois serve ambas.
            req.Headers.Add("Authorization", "Bearer " + chave);
            req.Timeout = timeoutMs;
            req.ReadWriteTimeout = timeoutMs;

            byte[] dados = Encoding.UTF8.GetBytes(corpo);
            req.ContentLength = dados.Length;
            using (var s = req.GetRequestStream()) s.Write(dados, 0, dados.Length);
            using (var resp = (HttpWebResponse)req.GetResponse())
            using (var sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8))
                return sr.ReadToEnd();
        }

        // ==================================================================
        // Estado local: DPAPI + cópia de segurança
        // ==================================================================

        private static Estado Carregar()
        {
            lock (_lock)
            {
                if (_estado != null) return _estado;
                try
                {
                    if (File.Exists(Ficheiro))
                    {
                        _estado = Interpretar(File.ReadAllBytes(Ficheiro));
                        if (_estado != null) return _estado;
                    }
                }
                catch { }

                // Principal corrompido (falha de energia a meio da escrita):
                // sem este recurso o cliente pagante aparecia "sem licença".
                try
                {
                    string bak = Ficheiro + ".bak";
                    if (File.Exists(bak))
                    {
                        _estado = Interpretar(File.ReadAllBytes(bak));
                        // Repara o principal, senão o próximo Guardar copiava
                        // o ficheiro estragado por cima do backup bom.
                        if (_estado != null) try { File.Copy(bak, Ficheiro, true); } catch { }
                    }
                }
                catch { }
                return _estado;
            }
        }

        private static Estado Interpretar(byte[] cifrado)
        {
            try
            {
                string txt = Encoding.UTF8.GetString(ProtectedData.Unprotect(
                    cifrado, null, DataProtectionScope.CurrentUser));
                return new Estado
                {
                    Codigo = Extrair(txt, "codigo") ?? "",
                    Cliente = Extrair(txt, "cliente") ?? "",
                    Email = Extrair(txt, "email") ?? "",
                    Motivo = Extrair(txt, "motivo") ?? "",
                    ExpiraEm = Data(Extrair(txt, "expira_em")),
                    UltimaVerificacao = Data(Extrair(txt, "verificado_em"))
                };
            }
            catch { return null; }
        }

        private static void Guardar(Estado e)
        {
            lock (_lock)
            {
                _estado = e;
                try
                {
                    Directory.CreateDirectory(Pasta);
                    if (File.Exists(Ficheiro))
                        try { File.Copy(Ficheiro, Ficheiro + ".bak", true); } catch { }

                    string txt = "{" +
                        Campo("codigo", e.Codigo) + "," +
                        Campo("cliente", e.Cliente) + "," +
                        Campo("email", e.Email) + "," +
                        Campo("motivo", e.Motivo) + "," +
                        Campo("expira_em", e.ExpiraEm.ToString("o", CultureInfo.InvariantCulture)) + "," +
                        Campo("verificado_em", e.UltimaVerificacao.ToString("o", CultureInfo.InvariantCulture)) + "}";
                    File.WriteAllBytes(Ficheiro, ProtectedData.Protect(
                        Encoding.UTF8.GetBytes(txt), null, DataProtectionScope.CurrentUser));
                }
                catch { }
            }
        }

        /// <summary>Remove a licença deste posto (testes, mudança de PC). Não mexe na identidade.</summary>
        public static void Limpar()
        {
            lock (_lock)
            {
                _estado = null;
                try { File.Delete(Ficheiro); } catch { }
                try { File.Delete(Ficheiro + ".bak"); } catch { }
            }
        }

        // ==================================================================
        // JSON mínimo (sem dependências: o net48 não traz System.Text.Json)
        // ==================================================================

        private static string VersaoPlugin()
        {
            try { return Assembly.GetExecutingAssembly().GetName().Version.ToString(); }
            catch { return "?"; }
        }

        private static string Normalizar(string codigo)
        {
            return string.IsNullOrWhiteSpace(codigo) ? ""
                : Regex.Replace(codigo, "[^A-Za-z0-9]", "").ToUpperInvariant();
        }

        internal static string Campo(string nome, string valor)
        {
            var sb = new StringBuilder();
            sb.Append('"').Append(nome).Append("\":\"");
            foreach (char c in valor ?? "")
            {
                if (c == '"') sb.Append("\\\"");
                else if (c == '\\') sb.Append("\\\\");
                else if (c < 0x20) sb.Append("\\u").Append(((int)c).ToString("x4"));
                else sb.Append(c);
            }
            return sb.Append('"').ToString();
        }

        internal static string Extrair(string json, string campo)
        {
            var m = Regex.Match(json, "\"" + Regex.Escape(campo) + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
            if (m.Success) return Regex.Unescape(m.Groups[1].Value);
            m = Regex.Match(json, "\"" + Regex.Escape(campo) + "\"\\s*:\\s*([^,}\\s]+)");
            return m.Success && m.Groups[1].Value != "null" ? m.Groups[1].Value : null;
        }

        private static DateTime Data(string s)
        {
            DateTime dt;
            return DateTime.TryParse(s, CultureInfo.InvariantCulture,
                DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out dt)
                ? dt : DateTime.MinValue;
        }
    }

    /// <summary>
    /// url + chave publishable. Fora da DLL de propósito: muda-se de projecto
    /// Supabase sem recompilar. Procura primeiro ao lado da DLL, depois em
    /// %APPDATA%\Produto. Licença E telemetria têm de ler DAQUI — no TSK a
    /// telemetria lia outro ficheiro e deixou de enviar sem ninguém dar por isso.
    /// </summary>
    public static class ConfigSupabase
    {
        public static bool Ler(string produto, out string url, out string chave)
        {
            url = null; chave = null;
            try
            {
                string junto = Path.Combine(Path.GetDirectoryName(
                    Assembly.GetExecutingAssembly().Location) ?? "", "supabase.json");
                string appData = Path.Combine(Environment.GetFolderPath(
                    Environment.SpecialFolder.ApplicationData), produto, "supabase.json");
                string f = File.Exists(junto) ? junto : appData;
                if (!File.Exists(f)) return false;

                string txt = File.ReadAllText(f);
                url = Licenca.Extrair(txt, "url");
                chave = Licenca.Extrair(txt, "chave") ?? Licenca.Extrair(txt, "key");

                // Nunca aceitar uma chave de administração no cliente.
                if (chave != null && (chave.StartsWith("sb_secret_") || EhJwtServiceRole(chave)))
                    return false;
                return !string.IsNullOrWhiteSpace(url) && !string.IsNullOrWhiteSpace(chave);
            }
            catch { return false; }
        }

        private static bool EhJwtServiceRole(string jwt)
        {
            try
            {
                string[] p = jwt.Split('.');
                if (p.Length != 3) return false;
                string b = p[1].Replace('-', '+').Replace('_', '/');
                b = b.PadRight(b.Length + (4 - b.Length % 4) % 4, '=');
                return Encoding.UTF8.GetString(Convert.FromBase64String(b)).Contains("\"service_role\"");
            }
            catch { return false; }
        }
    }
}

<#
    Ataca o Supabase COM A CHAVE PUBLICA, como qualquer cliente pode.

    A chave anon/publishable viaja com o plugin. Este script usa-a e verifica:

      NEGATIVO  o anon NAO emite licencas, NAO le codigos, NAO le e-mails.
      POSITIVO  o anon CONTINUA a activar, verificar e pedir avaliacao.
                Fechar de mais e pior do que a fuga: um plugin que nao
                licencia esta avariado para toda a gente.

    Uso:
        .\testar_anon.ps1 -Config "C:\caminho\supabase.json"

    Nao pede trial a serio (gastaria a avaliacao desta maquina): manda um
    pedido invalido e so confirma que a funcao RESPONDE em vez de recusar.

    Ficheiro so ASCII de proposito: o powershell.exe 5.1 le .ps1 sem BOM
    como ANSI e acentos em UTF-8 partem o script.
#>
param([Parameter(Mandatory = $true)][string]$Config)

$ErrorActionPreference = 'Continue'
$cfg = Get-Content -Raw -LiteralPath $Config | ConvertFrom-Json
$url = $cfg.url.TrimEnd('/')
$key = if ($cfg.chave) { $cfg.chave } else { $cfg.key }

if ($key -like 'sb_secret_*' -or $key -match '^eyJ.*\.eyJ') {
    if ($key -like 'sb_secret_*') {
        Write-Host "ALERTA: o supabase.json tem uma chave SECRETA. Nunca distribuir isto." -ForegroundColor Red
        exit 2
    }
    $meio = $key.Split('.')[1].Replace('-', '+').Replace('_', '/')
    $meio = $meio.PadRight($meio.Length + (4 - $meio.Length % 4) % 4, '=')
    $claims = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($meio))
    if ($claims -match '"service_role"') {
        Write-Host "ALERTA: o supabase.json tem a chave service_role. Rodar a chave JA." -ForegroundColor Red
        exit 2
    }
}

$cab = @{ apikey = $key; Authorization = "Bearer $key" }
$falhas = 0

function Testar([string]$Nome, [scriptblock]$Accao, [bool]$DeveFalhar) {
    try {
        $r = & $Accao
        # Sem excepcao: o servidor aceitou. Um GET que devolve [] tambem conta
        # como aceite - quer dizer que o privilegio existe e so a RLS tapou.
        $passou = -not $DeveFalhar
        $det = if ($r) { ($r | ConvertTo-Json -Compress -Depth 3) } else { "(vazio - privilegio existe)" }
        if ($det.Length -gt 90) { $det = $det.Substring(0, 90) + "..." }
    }
    catch {
        $cod = ""; try { $cod = $_.Exception.Response.StatusCode.value__ } catch { }
        $passou = $DeveFalhar
        $det = "recusado (HTTP $cod)"
    }
    $cor = if ($passou) { 'Green' } else { 'Red' }
    Write-Host ("{0}  {1,-44} {2}" -f $(if ($passou) { '  OK  ' } else { ' FALHA' }), $Nome, $det) -ForegroundColor $cor
    if (-not $passou) { $script:falhas++ }
}

function Rpc($f, $corpo) {
    Invoke-RestMethod -Method Post -Uri "$url/rest/v1/rpc/$f" -Headers $cab -ContentType 'application/json' -Body $corpo
}
function Ler($o) { Invoke-RestMethod -Method Get -Uri "$url/rest/v1/$o" -Headers $cab }

Write-Host "`nprojecto: $url`n"
Write-Host "NEGATIVO - o anon nao pode" -ForegroundColor Yellow
Testar "emitir_licenca"               { Rpc 'emitir_licenca' '{"p_cliente":"intrusao"}' } $true
Testar "estender_trial"               { Rpc 'estender_trial' '{"p_email":"x@x.pt"}' } $true
Testar "libertar_posto"               { Rpc 'libertar_posto' '{"p_codigo":"x","p_instalacao":"x"}' } $true
Testar "ler vw_licencas (codigos)"    { Ler 'vw_licencas?limit=1' } $true
Testar "ler vw_postos"                { Ler 'vw_postos?limit=1' } $true
Testar "ler licencas"                 { Ler 'licencas?select=codigo&limit=1' } $true
Testar "ler trials (e-mails)"         { Ler 'trials?select=email&limit=1' } $true
Testar "ler sessoes"                  { Ler 'sessoes?limit=1' } $true

Write-Host "`nPOSITIVO - o plugin precisa" -ForegroundColor Yellow
Testar "activar_licenca responde"     { Rpc 'activar_licenca' '{"p_codigo":"TESTE-0000","p_instalacao":"TESTE-PS"}' } $false
Testar "verificar_licenca responde"   { Rpc 'verificar_licenca' '{"p_codigo":"TESTE-0000","p_instalacao":"TESTE-PS"}' } $false
Testar "pedir_trial responde"         { Rpc 'pedir_trial' '{"p_instalacao":""}' } $false

Write-Host ""
if ($falhas -eq 0) { Write-Host "Tudo certo: fechado para o anon e o plugin continua a licenciar." -ForegroundColor Green; exit 0 }
Write-Host "$falhas verificacao(oes) falharam." -ForegroundColor Red
exit 1

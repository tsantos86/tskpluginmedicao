-- =====================================================================
--  Licenciamento de plugin desktop — esquema Supabase consolidado
--
--  Destilado do TSK TakeOff (schema.sql + comercial.sql + as três
--  correcções que foi preciso aplicar em produção). Corre de uma vez, num
--  projecto novo, no SQL Editor (como `postgres`). No fim há uma consulta
--  de verificação: a primeira linha tem de dizer "passa".
--
--  Nomes genéricos: `instalacao` em vez de `maquina`, `versao_host` em vez
--  de `versao_autocad`. O host pode ser Revit, AutoCAD, o que for.
--
--  MODELO DE AMEAÇA — ler antes de mexer:
--  A chave anon/publishable viaja com o plugin e qualquer pessoa a extrai.
--  O esquema NÃO confia nela: tabelas com RLS a negar tudo, e o anon só
--  executa três funções (activar, verificar, pedir trial) que devolvem
--  sim/não. Tudo o que é administração exige service_role.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 0. Fechar por omissão ANTES de criar o que quer que seja
-- ---------------------------------------------------------------------
-- Projectos Supabase com os privilégios por omissão antigos dão ao anon uma
-- concessão PRÓPRIA em cada tabela/função/vista nova. `revoke ... from
-- public` NÃO a remove (PUBLIC e anon são papéis diferentes). No TSK isto
-- deixou emitir_licenca e a vista com os códigos de todos os clientes ao
-- alcance da chave que vai dentro da DLL. Daqui para a frente, nada nasce
-- aberto; o que o plugin precisa é concedido à mão, mais abaixo.
alter default privileges for role postgres in schema public
    revoke all on tables    from anon, authenticated;
alter default privileges for role postgres in schema public
    revoke all on sequences from anon, authenticated;
alter default privileges for role postgres in schema public
    revoke all on functions from anon, authenticated, public;


-- ---------------------------------------------------------------------
-- 1. Tabelas
-- ---------------------------------------------------------------------
create table if not exists public.licencas (
    id                uuid primary key default gen_random_uuid(),
    codigo            text unique not null,          -- ex.: ABC-1A2B-3C4D-5E6F
    cliente           text,
    email             text,
    dias              integer not null default 30,   -- janela de cada (re)validação
    max_dispositivos  integer not null default 1,
    activa            boolean not null default true, -- false = revogada
    valida_ate        timestamptz,                   -- limite absoluto (opcional)
    criada_em         timestamptz not null default now(),
    notas             text
);

create table if not exists public.activacoes (
    id                 uuid primary key default gen_random_uuid(),
    licenca_id         uuid not null references public.licencas(id) on delete cascade,
    instalacao         text not null,                -- GUID opaco gerado pelo plugin
    utilizador         text,
    versao_host        text,
    versao_plugin      text,
    activada_em        timestamptz not null default now(),
    expira_em          timestamptz not null,
    ultima_verificacao timestamptz not null default now(),
    bloqueada          boolean not null default false,
    unique (licenca_id, instalacao)
);
create index if not exists idx_activacoes_instalacao on public.activacoes(instalacao);

-- Uma linha por instalação que alguma vez pediu avaliação. O e-mail é a
-- segunda trava: apagar o ficheiro local gera outro GUID, mas o e-mail é o
-- mesmo e o servidor reconhece-o.
create table if not exists public.trials (
    id            uuid primary key default gen_random_uuid(),
    instalacao    text not null unique,
    email         text,
    utilizador    text,
    iniciado_em   timestamptz not null default now(),
    expira_em     timestamptz not null,
    convertido    boolean not null default false,
    versao_host   text,
    versao_plugin text
);
create index if not exists idx_trials_email on public.trials (lower(email));

-- Telemetria sem dados pessoais: nem utilizador, nem máquina, nem domínio.
-- Juntos identificam uma pessoa; e não são precisos para contar instalações.
create table if not exists public.sessoes (
    id            bigserial primary key,
    instalacao    text,
    versao_host   text,
    versao_plugin text,
    sistema       text,
    cultura       text,
    inicio        timestamptz,
    recebido_em   timestamptz not null default now()
);


-- ---------------------------------------------------------------------
-- 2. RLS: negar tudo; a telemetria é a única excepção (só INSERT)
-- ---------------------------------------------------------------------
alter table public.licencas   enable row level security;
alter table public.activacoes enable row level security;
alter table public.trials     enable row level security;
alter table public.sessoes    enable row level security;

drop policy if exists "sessoes: inserir" on public.sessoes;
create policy "sessoes: inserir" on public.sessoes
    for insert to anon, authenticated with check (true);

revoke all on public.licencas, public.activacoes, public.trials, public.sessoes
    from anon, authenticated, public;
grant insert on public.sessoes to anon, authenticated;
grant usage on sequence public.sessoes_id_seq to anon, authenticated;

-- O painel (service_role) precisa das tabelas porque as vistas abaixo correm
-- com as permissões de quem as consulta (security_invoker).
grant select, insert, update, delete
    on public.licencas, public.activacoes, public.trials, public.sessoes
    to service_role;


-- ---------------------------------------------------------------------
-- 3. Utilitários
-- ---------------------------------------------------------------------
-- O cliente cola o código como calhar: "abc 1a2b-3c4d 5e6f". Todas as funções
-- comparam pela forma normalizada. No TSK só o activar fazia isto; o revogar
-- exigia o código exacto e respondia "não encontrado" a um pedido urgente.
create or replace function public.normalizar_codigo(p text)
returns text language sql immutable as $$
    select upper(regexp_replace(coalesce(p, ''), '[^A-Za-z0-9]', '', 'g'))
$$;

-- 48 bits de aleatoriedade forte (UUID v4), sem depender do pgcrypto — que no
-- Supabase vive no schema `extensions` e falha com search_path = public.
-- Mudar o prefixo por produto.
create or replace function public.gerar_codigo()
returns text language sql volatile as $$
    select 'ABC-' || substr(h, 1, 4) || '-' || substr(h, 5, 4) || '-' || substr(h, 9, 4)
      from (select upper(replace(gen_random_uuid()::text, '-', '')) as h) x
$$;

create or replace function public.dias_de_trial()
returns integer language sql immutable as $$ select 15 $$;


-- ---------------------------------------------------------------------
-- 4. Funções do PLUGIN (anon)
-- ---------------------------------------------------------------------
create or replace function public.activar_licenca(
    p_codigo        text,
    p_instalacao    text,
    p_utilizador    text default null,
    p_versao_host   text default null,
    p_versao_plugin text default null
)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
    v_lic       public.licencas%rowtype;
    v_act       public.activacoes%rowtype;
    v_usados    integer;
    v_expira    timestamptz;
begin
    if nullif(trim(p_instalacao), '') is null then
        return json_build_object('ok', false, 'motivo', 'Instalação não identificada.');
    end if;

    -- FOR UPDATE serializa activações da mesma licença: sem isto, dois postos
    -- a activar ao mesmo tempo passam ambos a contagem e excedem o limite.
    select * into v_lic
      from public.licencas
     where normalizar_codigo(codigo) = normalizar_codigo(p_codigo)
       for update;

    if not found then
        return json_build_object('ok', false, 'motivo', 'Código não encontrado.');
    end if;
    if not v_lic.activa then
        return json_build_object('ok', false, 'motivo', 'Licença desactivada.');
    end if;
    if v_lic.valida_ate is not null and v_lic.valida_ate < now() then
        return json_build_object('ok', false, 'motivo', 'Licença caducada.');
    end if;

    select * into v_act
      from public.activacoes
     where licenca_id = v_lic.id and instalacao = p_instalacao;

    if not found then
        select count(*) into v_usados
          from public.activacoes
         where licenca_id = v_lic.id and not bloqueada;
        if v_usados >= v_lic.max_dispositivos then
            return json_build_object('ok', false, 'motivo',
                format('Licença já usada em %s posto(s). Limite atingido.', v_usados));
        end if;
    elsif v_act.bloqueada then
        return json_build_object('ok', false, 'motivo', 'Este posto foi bloqueado.');
    end if;

    v_expira := now() + make_interval(days => v_lic.dias);
    if v_lic.valida_ate is not null and v_expira > v_lic.valida_ate then
        v_expira := v_lic.valida_ate;
    end if;

    insert into public.activacoes as a
        (licenca_id, instalacao, utilizador, versao_host, versao_plugin, expira_em)
    values
        (v_lic.id, p_instalacao, p_utilizador, p_versao_host, p_versao_plugin, v_expira)
    on conflict (licenca_id, instalacao) do update
        set expira_em          = excluded.expira_em,
            utilizador         = coalesce(excluded.utilizador, a.utilizador),
            versao_host        = coalesce(excluded.versao_host, a.versao_host),
            versao_plugin      = coalesce(excluded.versao_plugin, a.versao_plugin),
            ultima_verificacao = now();

    -- Converte o trial desta instalação, para o funil.
    update public.trials set convertido = true where instalacao = p_instalacao;

    return json_build_object('ok', true, 'cliente', v_lic.cliente,
                             'expira_em', v_expira, 'dias', v_lic.dias);
end;
$$;

create or replace function public.verificar_licenca(
    p_codigo     text,
    p_instalacao text
)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
    v_lic    public.licencas%rowtype;
    v_act    public.activacoes%rowtype;
    v_expira timestamptz;
begin
    select * into v_lic
      from public.licencas
     where normalizar_codigo(codigo) = normalizar_codigo(p_codigo);

    if not found or not v_lic.activa then
        return json_build_object('ok', false, 'motivo', 'Licença inválida ou desactivada.');
    end if;
    if v_lic.valida_ate is not null and v_lic.valida_ate < now() then
        return json_build_object('ok', false, 'motivo', 'Licença caducada.');
    end if;

    select * into v_act
      from public.activacoes
     where licenca_id = v_lic.id and instalacao = p_instalacao;

    if not found then
        return json_build_object('ok', false, 'motivo', 'Posto não activado.');
    end if;
    if v_act.bloqueada then
        return json_build_object('ok', false, 'motivo', 'Este posto foi bloqueado.');
    end if;

    -- Cada verificação online bem sucedida empurra a janela para a frente.
    v_expira := now() + make_interval(days => v_lic.dias);
    if v_lic.valida_ate is not null and v_expira > v_lic.valida_ate then
        v_expira := v_lic.valida_ate;
    end if;

    update public.activacoes
       set expira_em = v_expira, ultima_verificacao = now()
     where id = v_act.id;

    return json_build_object('ok', true, 'cliente', v_lic.cliente, 'expira_em', v_expira);
end;
$$;

create or replace function public.pedir_trial(
    p_instalacao    text,
    p_email         text default null,
    p_utilizador    text default null,
    p_versao_host   text default null,
    p_versao_plugin text default null
)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
    v_trial public.trials%rowtype;
    v_email text := lower(nullif(trim(p_email), ''));
begin
    if nullif(trim(p_instalacao), '') is null then
        return json_build_object('ok', false, 'motivo', 'Instalação não identificada.');
    end if;
    if v_email is null or v_email !~ '^[^\s@]+@[^\s@]+\.[^\s@]+$' then
        return json_build_object('ok', false, 'motivo', 'Indique um e-mail válido.');
    end if;

    -- Serializa por e-mail: duas instalações não abrem dois trials para o
    -- mesmo endereço em pedidos simultâneos.
    perform pg_advisory_xact_lock(hashtext('trial|' || v_email));

    -- Reconhece a instalação OU o e-mail. É isto que impede recomeçar a
    -- avaliação apagando o ficheiro local ou trocando de endereço no mesmo PC.
    select * into v_trial
      from public.trials
     where instalacao = trim(p_instalacao)
        or lower(email) = v_email
     order by expira_em desc
     limit 1;

    if not found then
        insert into public.trials (instalacao, email, utilizador, expira_em,
                                   versao_host, versao_plugin)
        values (trim(p_instalacao), v_email, p_utilizador,
                now() + make_interval(days => public.dias_de_trial()),
                p_versao_host, p_versao_plugin)
        returning * into v_trial;

        return json_build_object('ok', true, 'cliente', 'Avaliação',
            'expira_em', v_trial.expira_em,
            'motivo', format('Avaliação de %s dias iniciada.', public.dias_de_trial()));
    end if;

    if v_trial.expira_em > now() then
        update public.trials
           set utilizador    = coalesce(p_utilizador, utilizador),
               versao_host   = coalesce(p_versao_host, versao_host),
               versao_plugin = coalesce(p_versao_plugin, versao_plugin)
         where id = v_trial.id;

        return json_build_object('ok', true, 'cliente', 'Avaliação',
            'expira_em', v_trial.expira_em, 'motivo', 'Avaliação em curso.');
    end if;

    return json_build_object('ok', false,
        'motivo', 'A avaliação gratuita já terminou nesta instalação ou e-mail.');
end;
$$;

-- Só estas três ficam ao alcance da chave que vai com o plugin.
grant execute on function public.activar_licenca(text, text, text, text, text)   to anon, authenticated;
grant execute on function public.verificar_licenca(text, text)                   to anon, authenticated;
grant execute on function public.pedir_trial(text, text, text, text, text)       to anon, authenticated;


-- ---------------------------------------------------------------------
-- 5. Funções de ADMINISTRAÇÃO (só service_role)
-- ---------------------------------------------------------------------
create or replace function public.emitir_licenca(
    p_cliente          text,
    p_email            text default null,
    p_dias             integer default 30,
    p_max_dispositivos integer default 1,
    p_valida_ate       date default null,
    p_notas            text default null
)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
    v_codigo text := public.gerar_codigo();
begin
    if nullif(trim(p_cliente), '') is null then
        raise exception 'O nome do cliente é obrigatório.';
    end if;

    insert into public.licencas (codigo, cliente, email, dias, max_dispositivos, valida_ate, notas)
    values (v_codigo, trim(p_cliente), lower(nullif(trim(p_email), '')),
            greatest(p_dias, 1), greatest(p_max_dispositivos, 1), p_valida_ate,
            nullif(trim(coalesce(p_notas, '')), ''));   -- no TSK as notas eram aceites e deitadas fora

    if nullif(trim(p_email), '') is not null then
        update public.trials set convertido = true where lower(email) = lower(trim(p_email));
    end if;

    return json_build_object('ok', true, 'codigo', v_codigo, 'cliente', trim(p_cliente),
        'dias', greatest(p_dias, 1), 'max_dispositivos', greatest(p_max_dispositivos, 1),
        'valida_ate', p_valida_ate);
end;
$$;

create or replace function public.renovar_licenca(p_codigo text, p_valida_ate date)
returns json language plpgsql security definer set search_path = public as $$
declare v_codigo text;
begin
    update public.licencas set valida_ate = p_valida_ate, activa = true
     where normalizar_codigo(codigo) = normalizar_codigo(p_codigo)
    returning codigo into v_codigo;
    if v_codigo is null then
        return json_build_object('ok', false, 'motivo', 'Código não encontrado.');
    end if;
    return json_build_object('ok', true, 'codigo', v_codigo, 'valida_ate', p_valida_ate);
end;
$$;

-- O posto só perde acesso na revalidação seguinte: no arranque seguinte com
-- rede, ou no máximo `dias` dias depois. Não prometer corte imediato.
create or replace function public.revogar_licenca(p_codigo text)
returns json language plpgsql security definer set search_path = public as $$
declare v_codigo text;
begin
    update public.licencas set activa = false
     where normalizar_codigo(codigo) = normalizar_codigo(p_codigo)
    returning codigo into v_codigo;
    if v_codigo is null then
        return json_build_object('ok', false, 'motivo', 'Código não encontrado.');
    end if;
    return json_build_object('ok', true, 'codigo', v_codigo);
end;
$$;

-- "Preciso de mais 15 dias": estende a avaliação de um e-mail. Depois disto o
-- cliente abre o diálogo de licença e pede a avaliação outra vez, com o MESMO
-- e-mail — o plugin não revalida trials sozinho (é de propósito).
create or replace function public.estender_trial(p_email text, p_dias integer default 15)
returns json language plpgsql security definer set search_path = public as $$
declare v_n integer;
begin
    update public.trials
       set expira_em = greatest(expira_em, now()) + make_interval(days => greatest(p_dias, 1))
     where lower(email) = lower(trim(p_email));
    get diagnostics v_n = row_count;
    if v_n = 0 then
        return json_build_object('ok', false, 'motivo', 'Nenhuma avaliação com esse e-mail.');
    end if;
    return json_build_object('ok', true, 'linhas', v_n);
end;
$$;

-- Liberta um lugar para o cliente reinstalar noutro PC.
create or replace function public.libertar_posto(p_codigo text, p_instalacao text)
returns json language plpgsql security definer set search_path = public as $$
declare v_n integer;
begin
    delete from public.activacoes a
     using public.licencas l
     where a.licenca_id = l.id
       and normalizar_codigo(l.codigo) = normalizar_codigo(p_codigo)
       and a.instalacao = p_instalacao;
    get diagnostics v_n = row_count;
    return json_build_object('ok', v_n > 0, 'removidos', v_n);
end;
$$;

grant execute on function public.emitir_licenca(text, text, integer, integer, date, text) to service_role;
grant execute on function public.renovar_licenca(text, date)   to service_role;
grant execute on function public.revogar_licenca(text)         to service_role;
grant execute on function public.estender_trial(text, integer) to service_role;
grant execute on function public.libertar_posto(text, text)    to service_role;
grant execute on function public.gerar_codigo()                to service_role;
grant execute on function public.normalizar_codigo(text)       to service_role;
grant execute on function public.dias_de_trial()               to service_role;


-- ---------------------------------------------------------------------
-- 6. Vistas do painel — SEMPRE com security_invoker
-- ---------------------------------------------------------------------
-- Uma vista normal corre com as permissões do DONO e ignora a RLS das tabelas.
-- No TSK, vw_licencas expunha os códigos de todos os clientes à chave anon.
create or replace view public.vw_licencas with (security_invoker = true) as
select l.id, l.codigo, l.cliente, l.email, l.dias, l.max_dispositivos, l.valida_ate,
       l.activa, l.criada_em, l.notas,
       count(a.id) filter (where not a.bloqueada) as postos_activados,
       count(a.id) filter (where a.bloqueada)     as postos_bloqueados,
       max(a.ultima_verificacao)                  as ultima_utilizacao
  from public.licencas l
  left join public.activacoes a on a.licenca_id = l.id
 group by l.id;

create or replace view public.vw_postos with (security_invoker = true) as
select a.id, l.cliente, l.codigo, a.instalacao, a.utilizador, a.versao_host,
       a.versao_plugin, a.expira_em, a.ultima_verificacao, a.bloqueada
  from public.activacoes a
  join public.licencas l on l.id = a.licenca_id;

create or replace view public.vw_funil with (security_invoker = true) as
select count(*)                                  as trials_total,
       count(*) filter (where expira_em > now()) as trials_activos,
       count(*) filter (where convertido)        as convertidos,
       round(100.0 * count(*) filter (where convertido) / nullif(count(*), 0), 1)
                                                 as taxa_conversao_pct
  from public.trials;

revoke all on public.vw_licencas, public.vw_postos, public.vw_funil
    from anon, authenticated, public;
grant select on public.vw_licencas, public.vw_postos, public.vw_funil to service_role;


-- =====================================================================
--  VERIFICAÇÃO — falhas aparecem em cima. Primeira linha "passa" = fechado.
-- =====================================================================
select case when obtido is distinct from esperado then '>>> FALHA' else 'passa' end as estado,
       verificacao, obtido, esperado
  from (values
    ('anon NAO emite',        has_function_privilege('anon','public.emitir_licenca(text,text,integer,integer,date,text)','EXECUTE'), false),
    ('anon NAO renova',       has_function_privilege('anon','public.renovar_licenca(text,date)','EXECUTE'), false),
    ('anon NAO revoga',       has_function_privilege('anon','public.revogar_licenca(text)','EXECUTE'), false),
    ('anon NAO estende trial',has_function_privilege('anon','public.estender_trial(text,integer)','EXECUTE'), false),
    ('anon NAO liberta posto',has_function_privilege('anon','public.libertar_posto(text,text)','EXECUTE'), false),
    ('anon NAO gera codigos', has_function_privilege('anon','public.gerar_codigo()','EXECUTE'), false),
    ('anon NAO le licencas',  has_table_privilege('anon','public.licencas','SELECT'), false),
    ('anon NAO le activacoes',has_table_privilege('anon','public.activacoes','SELECT'), false),
    ('anon NAO le trials',    has_table_privilege('anon','public.trials','SELECT'), false),
    ('anon NAO le sessoes',   has_table_privilege('anon','public.sessoes','SELECT'), false),
    ('anon NAO le vw_licencas',has_table_privilege('anon','public.vw_licencas','SELECT'), false),
    ('anon NAO le vw_postos', has_table_privilege('anon','public.vw_postos','SELECT'), false),
    ('anon NAO le vw_funil',  has_table_privilege('anon','public.vw_funil','SELECT'), false),
    ('plugin activa',         has_function_privilege('anon','public.activar_licenca(text,text,text,text,text)','EXECUTE'), true),
    ('plugin verifica',       has_function_privilege('anon','public.verificar_licenca(text,text)','EXECUTE'), true),
    ('plugin pede trial',     has_function_privilege('anon','public.pedir_trial(text,text,text,text,text)','EXECUTE'), true),
    ('plugin envia sessoes',  has_table_privilege('anon','public.sessoes','INSERT'), true),
    ('painel emite',          has_function_privilege('service_role','public.emitir_licenca(text,text,integer,integer,date,text)','EXECUTE'), true),
    ('painel revoga',         has_function_privilege('service_role','public.revogar_licenca(text)','EXECUTE'), true),
    ('painel le vw_licencas', has_table_privilege('service_role','public.vw_licencas','SELECT'), true),
    ('painel le licencas',    has_table_privilege('service_role','public.licencas','SELECT'), true)
  ) t(verificacao, obtido, esperado)
 order by (obtido is distinct from esperado) desc, verificacao;

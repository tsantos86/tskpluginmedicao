---
name: orquestrar-plugin
description: Orquestra o ciclo de um plugin .NET vendido com licença (Revit, AutoCAD) usando os agentes revisor-licenciamento e build-release-plugin e as skills licenciamento-plugin e excel-plugin-desktop. Três modos — `iniciar` (montar licenciamento/Excel num projecto novo), `auditoria` (rever segurança e licença), `release` (auditar + compilar + testar + empacotar, com portões entre etapas). Usar quando pedirem "/orquestrar-plugin", "faz a release completa", "prepara a versão para clientes", "audita e empacota", "monta o licenciamento neste projecto".
argument-hint: "[iniciar|auditoria|release] [versão] [--ofuscar] [--assinar]"
---

# Orquestrador do plugin

Corres **na conversa principal**. É obrigatório: no Claude Code um subagente
não consegue lançar outro subagente, por isso quem encadeia os agentes és tu.
Os agentes fazem o trabalho pesado; tu decides a ordem, os portões e o que
chega ao utilizador.

## Peças

| Peça | Tipo | Faz |
|---|---|---|
| `revisor-licenciamento` | agente | audita licença, Supabase, painel, ofuscação; só lê |
| `build-release-plugin` | agente | compila, testa, ofusca, assina, empacota, verifica |
| `licenciamento-plugin` | skill | desenho de referência + `references/` (SQL, C#, teste, painel) |
| `excel-plugin-desktop` | skill | exportação ClosedXML e Excel ao vivo por COM |

Se um agente não estiver disponível (não aparece na lista de tipos de agente),
diz ao utilizador que falta instalar o kit (`.claude/agents/` do projecto ou
`~/.claude/agents/`) e pára. Não imites o agente à mão sem dizer.

## Escolher o modo

Pelo argumento; sem argumento, pelo pedido. Na dúvida entre `auditoria` e
`release`, pergunta: a release produz artefactos e pode demorar.

---

## Modo `iniciar` — montar num projecto novo

Trabalho teu, sem agentes (é copiar e adaptar, não auditar).

1. Reconhece o projecto: host (Revit/AutoCAD/outro), `TargetFrameworks`,
   namespace raiz, onde ficam os comandos e o arranque
   (`IExternalApplication`/`IExtensionApplication`).
2. Pergunta o que entra: licenciamento, Excel, ou os dois. E o nome do produto
   e o prefixo dos códigos (ex.: `RVT-`).
3. Carrega as skills escolhidas e copia de `references/`, **sem escrever por
   cima de nada que exista** (se existir, mostra a diferença e pergunta):
   - `schema.sql` → `Supabase/schema.sql`, com o prefixo do código trocado em
     `gerar_codigo()`.
   - `Licenca.cs` → pasta do projecto, com o namespace trocado.
   - `painel-admin.html` → `Admin/` (confirma que o instalador não apanha esta pasta).
   - `testar_anon.ps1` → `Supabase/`.
   - `ExcelAoVivo.cs` → pasta do projecto, com o namespace trocado.
4. Referências no `.csproj`: `System.Security` (net48) /
   `System.Security.Cryptography.ProtectedData` (net8); `Microsoft.CSharp`
   (net48) para o Excel COM.
5. Liga ao host como na secção "Integração no Revit" da skill: `Configurar` +
   `VerificarNoArranque` no arranque, `PodeUsar()` só nos comandos que criam
   trabalho.
6. Compila todos os alvos e diz o resultado. Deixa ao utilizador, por escrito,
   o que só ele pode fazer: criar o projecto Supabase, correr o `schema.sql`,
   pôr o `supabase.json` com a chave publishable.

---

## Modo `auditoria`

1. Lança `revisor-licenciamento` com: caminho do projecto, host, o que mudou
   desde a última auditoria (se souberes), e **se a verificação ao vivo está
   autorizada** — só se o utilizador disse que sim nesta conversa.
2. Quando o relatório chegar, **confirma tu 1 ou 2 achados** abrindo o
   ficheiro:linha citado. Se um achado não se confirmar, retira-o e diz porquê.
3. Apresenta ao utilizador por gravidade. Pergunta se quer que corrijas; não
   corrijas sem resposta.

---

## Modo `release`

```
            ┌─► revisor-licenciamento ─┐
pedido ─────┤                          ├─► PORTÃO ─► verificação tua ─► entrega
            └─► build-release-plugin ──┘
```

1. **Parâmetros**: versão, `--ofuscar`, `--assinar` (dos argumentos ou do
   pedido). Confirma que o host (Revit/AutoCAD) está fechado:
   `Get-Process Revit, acad -ErrorAction SilentlyContinue`. Aberto → pede para
   fechar antes de lançar o build.
2. **Lança os dois agentes em paralelo, em segundo plano.** O build só escreve
   em pastas de saída locais, por isso não há risco em correr ao mesmo tempo
   que a auditoria. O que a auditoria decide é se o resultado **sai**, não se
   se compila.
   - revisor: mesmo prompt do modo `auditoria`, com foco no que muda nesta versão.
   - build: caminho, versão, flags, e "não instalar nem publicar".
3. **PORTÃO** (depois dos dois terminarem):
   - Revisor com **CRÍTICO** → a release **não sai**. Mostra os achados e
     pergunta se corriges e repetes.
   - Revisor com **ALTO** → mostra e pergunta se sai mesmo assim. Não decides tu.
   - Build com erro de compilação, teste a falhar, ofuscação pedida e não
     feita, ou chave secreta no pacote → **não sai**.
   - Um alvo que não compilou por falta do host (ex.: sem Revit 2025
     instalado) → sai só se o utilizador aceitar entregar sem essa geração.
4. **Verificação tua, independente** (não confies só nos relatórios):
   - os artefactos listados existem (Glob) e têm data de agora;
   - `FileVersion` de uma DLL do pacote = versão pedida;
   - `supabase.json` do pacote não tem `sb_secret_` nem `service_role`;
   - se diz "assinado", corre `signtool verify /pa` num ficheiro.
   Divergência entre o relatório do agente e o que vês → vale o que vês, e dizes.
5. **Entrega**: artefactos com caminho e versão, o que foi saltado, os achados
   que ficam em aberto, e o passo manual que ninguém automatiza — instalar numa
   máquina ou conta Windows limpa, abrir o host e correr um comando de cada
   classe excluída da ofuscação.

## Nunca sem confirmação explícita nesta conversa

- publicar, fazer upload, push ou tag;
- instalar nas pastas `Addins`/`ApplicationPlugins` desta máquina;
- correr `testar_anon.ps1` contra um Supabase real (se houver fuga, cria uma
  licença "intrusao");
- correr SQL num projecto Supabase;
- fechar o Revit/AutoCAD do utilizador.
